

These marketing/account update emails leverage Salesforce Marketing Cloud's javascript-based AMPScript scripting language.

See email1_NoScript.html for an example of how one of the emails looks without the AMPScript